package com.zybooks.workingprototype_infoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button Nl;
    private Button RF;
    private Button SV;
    private Button WL;
    TextView PLink;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(getWindow().FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
    // Link to FGCU Housing PDF
        PLink = findViewById(R.id.PLink);
        PLink.setMovementMethod(LinkMovementMethod.getInstance());

    // Start of next page buttons
        Nl = findViewById(R.id.Northlake);
        Nl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity_nl();
            }
        });
        RF = findViewById(R.id.Reef);
        RF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity_rf();
            }
        });
        SV = findViewById(R.id.Sovi);
        SV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity_sovi();
            }
        });
        WL = findViewById(R.id.Westlake);
        WL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity_wl();
            }
        });

    }
    public void activity_rf(){
        Intent intent = new Intent(this, RF.class);
        startActivity(intent);
    }
    public void activity_nl(){
        Intent intent = new Intent(this, NL.class);
        startActivity(intent);
    }
    public void activity_sovi(){
        Intent intent = new Intent(this, SOVI.class);
        startActivity(intent);
    }
    public void activity_wl(){
        Intent intent = new Intent(this, WL.class);
        startActivity(intent);
    }
    // End of Buttons from Home Page to other Pages



}